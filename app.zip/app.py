import discord
from discord.ext import commands, tasks
from discord import app_commands
from datetime import timedelta
import time
import re
import os
import asyncio
import aiosqlite
from dotenv import load_dotenv
from collections import defaultdict

# ================= LOAD ENV =================
load_dotenv()
TOKEN = ""

# ================= BOT SETUP =================
intents = discord.Intents.all()
bot = commands.Bot(command_prefix="!", intents=intents)

# ================= DATABASE =================
DB = "mod.db"

async def init_db():
    async with aiosqlite.connect(DB) as db:
        await db.execute("""
        CREATE TABLE IF NOT EXISTS warns (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER,
            guild_id INTEGER,
            reason TEXT,
            moderator_id INTEGER,
            timestamp TEXT DEFAULT (datetime('now'))
        )""")
        await db.execute("""
        CREATE TABLE IF NOT EXISTS mutes (
            user_id INTEGER,
            guild_id INTEGER,
            unmute_at TEXT,
            PRIMARY KEY (user_id, guild_id)
        )""")
        await db.execute("""
        CREATE TABLE IF NOT EXISTS settings (
            guild_id INTEGER PRIMARY KEY,
            log_channel TEXT,
            mute_role TEXT,
            anti_raid INTEGER DEFAULT 0,
            max_warns INTEGER DEFAULT 3
        )""")
        await db.execute("""
        CREATE TABLE IF NOT EXISTS notes (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER,
            guild_id INTEGER,
            note TEXT,
            moderator_id INTEGER,
            timestamp TEXT DEFAULT (datetime('now'))
        )""")
        # Permission grants table — lets admins give any user access to any command
        await db.execute("""
        CREATE TABLE IF NOT EXISTS cmd_permissions (
            guild_id INTEGER,
            user_id INTEGER,
            command_name TEXT,
            PRIMARY KEY (guild_id, user_id, command_name)
        )""")
        await db.commit()

# ================= IN-MEMORY DATA =================
spam_cache = defaultdict(list)
cooldowns = {}
blacklist = set()
whitelist_channels = set()
join_times = []
NEPALI_BADWORDS = {"muji","randi","chikne","gandu","gula","turi","machikne","haramiko"}
ENGLISH_BADWORDS = {"fuck","shit","bitch","asshole","bastard","nigga","nigger","cunt","whore","slut"}
LINKS = ["http://","https://","discord.gg","discord.com/invite"]
custom_badwords = set()

# ================= COLORS =================
RED    = 0xff4757
GREEN  = 0x2ed573
BLUE   = 0x1e90ff
ORANGE = 0xffa502
PURPLE = 0xa29bfe
DARK   = 0x2b2d31
CYAN   = 0x00d2d3

# ================= EMBED HELPERS =================
def make_embed(title, desc, color=DARK, footer=None):
    e = discord.Embed(title=title, description=desc, color=color)
    e.timestamp = discord.utils.utcnow()
    if footer:
        e.set_footer(text=footer)
    return e

def success_embed(desc):
    return make_embed("✅ Success", desc, GREEN)

def error_embed(desc):
    return make_embed("❌ Error", desc, RED)

def warn_embed(desc):
    return make_embed("⚠️ Warning", desc, ORANGE)

def info_embed(title, desc):
    return make_embed(title, desc, BLUE)

# ================= LOGGING =================
async def log_action(guild, embed_obj):
    async with aiosqlite.connect(DB) as db:
        cur = await db.execute("SELECT log_channel FROM settings WHERE guild_id=?", (guild.id,))
        row = await cur.fetchone()
    channel_name = row[0] if row and row[0] else "mod-logs"
    channel = discord.utils.get(guild.text_channels, name=channel_name)
    if channel:
        try:
            await channel.send(embed=embed_obj)
        except Exception:
            pass

# ================= CUSTOM PERMISSION CHECK =================
# Checks: server owner → native Discord perm → DB grant → deny
def mod_check(*perms):
    async def predicate(interaction: discord.Interaction) -> bool:
        # Server owner always allowed
        if interaction.user.id == interaction.guild.owner_id:
            return True
        # Native Discord permissions
        user_perms = interaction.user.guild_permissions
        if all(getattr(user_perms, p, False) for p in perms):
            return True
        # DB grant check
        cmd_name = interaction.command.name if interaction.command else ""
        async with aiosqlite.connect(DB) as db:
            cur = await db.execute(
                "SELECT 1 FROM cmd_permissions WHERE guild_id=? AND user_id=? AND command_name=?",
                (interaction.guild.id, interaction.user.id, cmd_name)
            )
            row = await cur.fetchone()
        if row:
            return True
        raise app_commands.MissingPermissions(list(perms))
    return app_commands.check(predicate)

# ================= TREE ERROR HANDLER =================
@bot.tree.error
async def on_app_command_error(interaction: discord.Interaction, error: app_commands.AppCommandError):
    if isinstance(error, app_commands.MissingPermissions):
        await interaction.response.send_message(
            embed=error_embed("You don't have permission to use this command.\nAn admin can grant it with `/permsgive`."),
            ephemeral=True
        )
    elif isinstance(error, app_commands.BotMissingPermissions):
        await interaction.response.send_message(
            embed=error_embed(f"I'm missing permissions: `{', '.join(error.missing_permissions)}`"),
            ephemeral=True
        )
    else:
        await interaction.response.send_message(
            embed=error_embed(f"An error occurred: {error}"),
            ephemeral=True
        )

# ================= WARN SYSTEM =================
async def add_warn(member, reason, moderator_id):
    async with aiosqlite.connect(DB) as db:
        await db.execute(
            "INSERT INTO warns (user_id, guild_id, reason, moderator_id) VALUES (?, ?, ?, ?)",
            (member.id, member.guild.id, reason, moderator_id)
        )
        await db.commit()
        cur = await db.execute(
            "SELECT COUNT(*) FROM warns WHERE user_id=? AND guild_id=?",
            (member.id, member.guild.id)
        )
        row = await cur.fetchone()
        return row[0]

async def get_warns(user_id, guild_id):
    async with aiosqlite.connect(DB) as db:
        cur = await db.execute(
            "SELECT id, reason, moderator_id, timestamp FROM warns WHERE user_id=? AND guild_id=? ORDER BY timestamp DESC",
            (user_id, guild_id)
        )
        return await cur.fetchall()

async def get_max_warns(guild_id):
    async with aiosqlite.connect(DB) as db:
        cur = await db.execute("SELECT max_warns FROM settings WHERE guild_id=?", (guild_id,))
        row = await cur.fetchone()
        return row[0] if row else 3

# ================= MUTE SYSTEM =================
async def get_or_create_mute_role(guild):
    role = discord.utils.get(guild.roles, name="Muted")
    if not role:
        role = await guild.create_role(name="Muted", color=discord.Color.dark_gray(), reason="Auto-created mute role")
        for channel in guild.channels:
            try:
                await channel.set_permissions(role, send_messages=False, speak=False, add_reactions=False)
            except Exception:
                pass
    return role

async def mute_member(member, duration_minutes=None):
    role = await get_or_create_mute_role(member.guild)
    await member.add_roles(role, reason="Moderation mute")
    if duration_minutes:
        unmute_at = discord.utils.utcnow() + timedelta(minutes=duration_minutes)
        async with aiosqlite.connect(DB) as db:
            await db.execute(
                "INSERT OR REPLACE INTO mutes (user_id, guild_id, unmute_at) VALUES (?, ?, ?)",
                (member.id, member.guild.id, unmute_at.isoformat())
            )
            await db.commit()

async def unmute_member(member):
    role = discord.utils.get(member.guild.roles, name="Muted")
    if role and role in member.roles:
        await member.remove_roles(role, reason="Unmuted")
    async with aiosqlite.connect(DB) as db:
        await db.execute("DELETE FROM mutes WHERE user_id=? AND guild_id=?", (member.id, member.guild.id))
        await db.commit()

# ================= ANTI-SPAM =================
def is_spam(uid):
    now = time.time()
    spam_cache[uid] = [t for t in spam_cache[uid] if now - t < 6]
    spam_cache[uid].append(now)
    return len(spam_cache[uid]) >= 6

def is_on_cooldown(uid):
    now = time.time()
    last = cooldowns.get(uid, 0)
    if now - last < 1.5:
        return True
    cooldowns[uid] = now
    return False

# ================= BADWORD CHECK =================
def badword_check(text):
    all_words = NEPALI_BADWORDS | ENGLISH_BADWORDS | custom_badwords
    for w in all_words:
        if re.search(rf"\b{re.escape(w)}\b", text.lower()):
            return True
    return False

# ================= PUNISHMENT =================
async def punish(message, reason, severe=False, auto=True):
    try:
        await message.delete()
    except Exception:
        pass

    max_warns = await get_max_warns(message.guild.id)
    warns = await add_warn(message.author, reason, bot.user.id)
    action_taken = "Warned"

    if severe or warns >= max_warns:
        await mute_member(message.author, 10)
        action_taken = "Auto-muted (10 min)"

    e = make_embed(
        "🔨 Auto-Moderation",
        f"**User:** {message.author.mention}\n"
        f"**Reason:** {reason}\n"
        f"**Action:** {action_taken}\n"
        f"**Warns:** {warns}/{max_warns}",
        RED
    )
    await message.channel.send(embed=e, delete_after=8)

    log_e = make_embed(
        "🤖 Auto-Mod Action",
        f"**User:** {message.author} (`{message.author.id}`)\n"
        f"**Channel:** {message.channel.mention}\n"
        f"**Reason:** {reason}\n"
        f"**Action:** {action_taken}\n"
        f"**Warns:** {warns}/{max_warns}",
        ORANGE
    )
    await log_action(message.guild, log_e)

# ================= EVENTS =================
@bot.event
async def on_ready():
    await init_db()
    await bot.tree.sync()
    check_mutes.start()
    print(f"✅ {bot.user} is online!")
    print(f"   Guilds: {len(bot.guilds)}")

@bot.event
async def on_member_join(member):
    now = time.time()
    join_times.append(now)
    recent = [t for t in join_times if now - t < 10]
    join_times.clear()
    join_times.extend(recent)

    if len(recent) >= 10:
        try:
            await member.kick(reason="Anti-raid: mass join detected")
            e = make_embed("🚨 Anti-Raid", f"Kicked {member} (mass join detected)", RED)
            await log_action(member.guild, e)
        except Exception:
            pass
        return

    age = (discord.utils.utcnow() - member.created_at).days
    if age < 3:
        try:
            await member.kick(reason="New account (less than 3 days old)")
            e = make_embed("🚪 Alt Kick", f"{member} was kicked — account too new ({age} days)", ORANGE)
            await log_action(member.guild, e)
        except Exception:
            pass
        return

    e = make_embed(
        "👋 Member Joined",
        f"**User:** {member.mention} (`{member.id}`)\n"
        f"**Account Age:** {age} days\n"
        f"**Total Members:** {member.guild.member_count}",
        GREEN
    )
    await log_action(member.guild, e)

@bot.event
async def on_member_remove(member):
    e = make_embed(
        "🚪 Member Left",
        f"**User:** {member} (`{member.id}`)\n"
        f"**Total Members:** {member.guild.member_count}",
        RED
    )
    await log_action(member.guild, e)

@bot.event
async def on_message(message):
    if message.author.bot:
        return
    if not message.guild:
        return

    if message.author.id in blacklist:
        try:
            await message.delete()
        except Exception:
            pass
        return

    if message.channel.id in whitelist_channels:
        await bot.process_commands(message)
        return

    if is_on_cooldown(message.author.id):
        await bot.process_commands(message)
        return

    content = message.content.lower()

    if is_spam(message.author.id):
        await punish(message, "Spam detected")
        return

    if "@everyone" in content or "@here" in content:
        if not message.author.guild_permissions.mention_everyone:
            await punish(message, "Unauthorized mass mention", True)
            return

    if any(l in content for l in LINKS):
        if not message.author.guild_permissions.manage_messages:
            await punish(message, "Unauthorized link")
            return

    if badword_check(content):
        await punish(message, "Inappropriate language")
        return

    await bot.process_commands(message)

@bot.event
async def on_message_edit(before, after):
    if before.author.bot:
        return
    if before.content == after.content:
        return
    e = make_embed(
        "✏️ Message Edited",
        f"**User:** {before.author.mention}\n"
        f"**Channel:** {before.channel.mention}\n"
        f"**Before:** {before.content[:500]}\n"
        f"**After:** {after.content[:500]}",
        BLUE
    )
    await log_action(before.guild, e)

@bot.event
async def on_message_delete(message):
    if message.author.bot:
        return
    e = make_embed(
        "🗑️ Message Deleted",
        f"**User:** {message.author.mention}\n"
        f"**Channel:** {message.channel.mention}\n"
        f"**Content:** {message.content[:500] if message.content else '*No text*'}",
        RED
    )
    await log_action(message.guild, e)

@bot.event
async def on_member_ban(guild, user):
    e = make_embed("🔨 Member Banned", f"**User:** {user} (`{user.id}`)", RED)
    await log_action(guild, e)

@bot.event
async def on_member_unban(guild, user):
    e = make_embed("✅ Member Unbanned", f"**User:** {user} (`{user.id}`)", GREEN)
    await log_action(guild, e)

# ================= BACKGROUND TASK: AUTO-UNMUTE =================
@tasks.loop(seconds=30)
async def check_mutes():
    now = discord.utils.utcnow().isoformat()
    async with aiosqlite.connect(DB) as db:
        cur = await db.execute(
            "SELECT user_id, guild_id FROM mutes WHERE unmute_at <= ?", (now,)
        )
        rows = await cur.fetchall()
        for uid, gid in rows:
            guild = bot.get_guild(gid)
            if not guild:
                continue
            member = guild.get_member(uid)
            if member:
                await unmute_member(member)
            else:
                await db.execute("DELETE FROM mutes WHERE user_id=? AND guild_id=?", (uid, gid))
        await db.commit()

# =================================================================
# ====================== SLASH COMMANDS ==========================
# =================================================================

# -------- KICK --------
@bot.tree.command(name="kick", description="Kick a member from the server")
@mod_check("kick_members")
@app_commands.describe(member="Member to kick", reason="Reason for kick")
async def kick(interaction: discord.Interaction, member: discord.Member, reason: str = "No reason provided"):
    if member.top_role >= interaction.user.top_role and interaction.user.id != interaction.guild.owner_id:
        await interaction.response.send_message(embed=error_embed("You cannot kick someone with an equal or higher role."), ephemeral=True)
        return
    try:
        await member.send(embed=warn_embed(f"You were kicked from **{interaction.guild.name}**\nReason: {reason}"))
    except Exception:
        pass
    await member.kick(reason=f"{reason} | By {interaction.user}")
    await interaction.response.send_message(embed=success_embed(f"**{member}** has been kicked.\nReason: {reason}"))
    e = make_embed("👢 Member Kicked", f"**User:** {member} (`{member.id}`)\n**Moderator:** {interaction.user}\n**Reason:** {reason}", ORANGE)
    await log_action(interaction.guild, e)

# -------- BAN --------
@bot.tree.command(name="ban", description="Ban a member from the server")
@mod_check("ban_members")
@app_commands.describe(member="Member to ban", reason="Reason for ban", delete_days="Days of messages to delete (0-7)")
async def ban(interaction: discord.Interaction, member: discord.Member, reason: str = "No reason provided", delete_days: int = 0):
    if member.top_role >= interaction.user.top_role and interaction.user.id != interaction.guild.owner_id:
        await interaction.response.send_message(embed=error_embed("You cannot ban someone with an equal or higher role."), ephemeral=True)
        return
    try:
        await member.send(embed=warn_embed(f"You were banned from **{interaction.guild.name}**\nReason: {reason}"))
    except Exception:
        pass
    await member.ban(reason=f"{reason} | By {interaction.user}", delete_message_days=min(delete_days, 7))
    await interaction.response.send_message(embed=success_embed(f"**{member}** has been banned.\nReason: {reason}"))
    e = make_embed("🔨 Member Banned", f"**User:** {member} (`{member.id}`)\n**Moderator:** {interaction.user}\n**Reason:** {reason}", RED)
    await log_action(interaction.guild, e)

# -------- SOFTBAN --------
@bot.tree.command(name="softban", description="Ban and immediately unban a user to delete their messages")
@mod_check("ban_members")
@app_commands.describe(member="Member to softban", reason="Reason for softban")
async def softban(interaction: discord.Interaction, member: discord.Member, reason: str = "No reason provided"):
    await interaction.response.defer()
    await member.ban(reason=f"Softban: {reason}", delete_message_days=7)
    await interaction.guild.unban(member, reason="Softban unban")
    await interaction.followup.send(embed=success_embed(f"**{member}** was softbanned (messages deleted).\nReason: {reason}"))
    e = make_embed("🪃 Member Softbanned", f"**User:** {member} (`{member.id}`)\n**Moderator:** {interaction.user}\n**Reason:** {reason}", ORANGE)
    await log_action(interaction.guild, e)

# -------- UNBAN --------
@bot.tree.command(name="unban", description="Unban a user by their ID")
@mod_check("ban_members")
@app_commands.describe(user_id="The user ID to unban", reason="Reason for unban")
async def unban(interaction: discord.Interaction, user_id: str, reason: str = "No reason provided"):
    try:
        user = await bot.fetch_user(int(user_id))
        await interaction.guild.unban(user, reason=f"{reason} | By {interaction.user}")
        await interaction.response.send_message(embed=success_embed(f"**{user}** has been unbanned."))
        e = make_embed("✅ Member Unbanned", f"**User:** {user} (`{user.id}`)\n**Moderator:** {interaction.user}\n**Reason:** {reason}", GREEN)
        await log_action(interaction.guild, e)
    except Exception as ex:
        await interaction.response.send_message(embed=error_embed(f"Could not unban: {ex}"), ephemeral=True)

# -------- MUTE --------
@bot.tree.command(name="mute", description="Mute a member")
@mod_check("manage_roles")
@app_commands.describe(member="Member to mute", duration="Duration in minutes (0 = permanent)", reason="Reason for mute")
async def mute_cmd(interaction: discord.Interaction, member: discord.Member, duration: int = 0, reason: str = "No reason provided"):
    await mute_member(member, duration if duration > 0 else None)
    dur_text = f"{duration} minute(s)" if duration > 0 else "permanent"
    await interaction.response.send_message(embed=success_embed(f"**{member}** has been muted ({dur_text}).\nReason: {reason}"))
    e = make_embed("🔇 Member Muted", f"**User:** {member} (`{member.id}`)\n**Moderator:** {interaction.user}\n**Duration:** {dur_text}\n**Reason:** {reason}", RED)
    await log_action(interaction.guild, e)

# -------- UNMUTE --------
@bot.tree.command(name="unmute", description="Unmute a member")
@mod_check("manage_roles")
@app_commands.describe(member="Member to unmute")
async def unmute_cmd(interaction: discord.Interaction, member: discord.Member):
    await unmute_member(member)
    await interaction.response.send_message(embed=success_embed(f"**{member}** has been unmuted."))
    e = make_embed("🔊 Member Unmuted", f"**User:** {member} (`{member.id}`)\n**Moderator:** {interaction.user}", GREEN)
    await log_action(interaction.guild, e)

# -------- TIMEOUT --------
@bot.tree.command(name="timeout", description="Timeout a member using Discord's native timeout")
@mod_check("moderate_members")
@app_commands.describe(member="Member to timeout", minutes="Duration in minutes", reason="Reason")
async def timeout_cmd(interaction: discord.Interaction, member: discord.Member, minutes: int, reason: str = "No reason provided"):
    until = discord.utils.utcnow() + timedelta(minutes=minutes)
    await member.timeout(until, reason=f"{reason} | By {interaction.user}")
    await interaction.response.send_message(embed=success_embed(f"**{member}** has been timed out for {minutes} minute(s).\nReason: {reason}"))
    e = make_embed("⏱️ Member Timed Out", f"**User:** {member} (`{member.id}`)\n**Moderator:** {interaction.user}\n**Duration:** {minutes} min\n**Reason:** {reason}", ORANGE)
    await log_action(interaction.guild, e)

# -------- UNTIMEOUT --------
@bot.tree.command(name="untimeout", description="Remove a member's timeout")
@mod_check("moderate_members")
@app_commands.describe(member="Member to untimeout")
async def untimeout_cmd(interaction: discord.Interaction, member: discord.Member):
    await member.timeout(None)
    await interaction.response.send_message(embed=success_embed(f"**{member}**'s timeout has been removed."))

# -------- WARN --------
@bot.tree.command(name="warn", description="Warn a member")
@mod_check("manage_messages")
@app_commands.describe(member="Member to warn", reason="Reason for warning")
async def warn_cmd(interaction: discord.Interaction, member: discord.Member, reason: str = "No reason provided"):
    max_warns = await get_max_warns(interaction.guild.id)
    count = await add_warn(member, reason, interaction.user.id)
    action = ""
    if count >= max_warns:
        await mute_member(member, 30)
        action = "\n⚠️ **Auto-muted for 30 min** (warn limit reached)"
    try:
        await member.send(embed=warn_embed(f"You were warned in **{interaction.guild.name}**\nReason: {reason}\nWarns: {count}/{max_warns}"))
    except Exception:
        pass
    await interaction.response.send_message(embed=warn_embed(f"**{member}** has been warned ({count}/{max_warns}).\nReason: {reason}{action}"))
    e = make_embed("⚠️ Member Warned", f"**User:** {member} (`{member.id}`)\n**Moderator:** {interaction.user}\n**Reason:** {reason}\n**Total Warns:** {count}/{max_warns}{action}", ORANGE)
    await log_action(interaction.guild, e)

# -------- WARNS LIST --------
@bot.tree.command(name="warns", description="View warns for a member")
@app_commands.describe(member="Member to check warns for")
async def warns_cmd(interaction: discord.Interaction, member: discord.Member):
    rows = await get_warns(member.id, interaction.guild.id)
    max_warns = await get_max_warns(interaction.guild.id)
    if not rows:
        await interaction.response.send_message(embed=info_embed("Warns", f"**{member}** has no warnings."))
        return
    desc = f"**{member}** has **{len(rows)}/{max_warns}** warnings:\n\n"
    for i, (wid, reason, mod_id, ts) in enumerate(rows[:10], 1):
        desc += f"`#{wid}` **{reason}** — <@{mod_id}> — {ts[:10]}\n"
    await interaction.response.send_message(embed=make_embed(f"Warns for {member}", desc, ORANGE))

# -------- CLEARWARN --------
@bot.tree.command(name="clearwarn", description="Clear a specific warning by ID")
@mod_check("administrator")
@app_commands.describe(warn_id="The warning ID to remove")
async def clearwarn(interaction: discord.Interaction, warn_id: int):
    async with aiosqlite.connect(DB) as db:
        cur = await db.execute("SELECT user_id FROM warns WHERE id=? AND guild_id=?", (warn_id, interaction.guild.id))
        row = await cur.fetchone()
        if not row:
            await interaction.response.send_message(embed=error_embed(f"No warning with ID `{warn_id}` found."), ephemeral=True)
            return
        await db.execute("DELETE FROM warns WHERE id=?", (warn_id,))
        await db.commit()
    await interaction.response.send_message(embed=success_embed(f"Warning `#{warn_id}` has been removed."))

# -------- PURGE (FIXED) --------
# Bug fix: Discord bulk-delete only works on messages < 14 days old.
# Messages older than 14 days are now deleted one-by-one as a fallback.
@bot.tree.command(name="purge", description="Delete a number of messages")
@mod_check("manage_messages")
@app_commands.describe(amount="Number of messages to delete (1-500)", member="Only delete messages from this member")
async def purge(interaction: discord.Interaction, amount: int, member: discord.Member = None):
    if amount < 1 or amount > 500:
        await interaction.response.send_message(embed=error_embed("Amount must be between 1 and 500."), ephemeral=True)
        return
    await interaction.response.defer(ephemeral=True)

    check = (lambda m: m.author == member) if member else None

    cutoff = discord.utils.utcnow() - timedelta(days=14)
    bulk_messages = []
    old_messages = []

    async for msg in interaction.channel.history(limit=amount * 3 if member else amount + 10):
        if check and not check(msg):
            continue
        if len(bulk_messages) + len(old_messages) >= amount:
            break
        if msg.created_at > cutoff:
            bulk_messages.append(msg)
        else:
            old_messages.append(msg)

    deleted_count = 0

    # Bulk delete recent messages (Discord API limit: max 100 per call)
    for i in range(0, len(bulk_messages), 100):
        chunk = bulk_messages[i:i+100]
        if chunk:
            try:
                await interaction.channel.delete_messages(chunk)
                deleted_count += len(chunk)
            except discord.HTTPException:
                pass

    # One-by-one for messages older than 14 days
    for msg in old_messages:
        try:
            await msg.delete()
            deleted_count += 1
            await asyncio.sleep(0.5)  # Avoid rate limits
        except discord.HTTPException:
            pass

    await interaction.followup.send(
        embed=success_embed(f"Deleted **{deleted_count}** message(s)."),
        ephemeral=True
    )
    e = make_embed(
        "🧹 Messages Purged",
        f"**Moderator:** {interaction.user}\n"
        f"**Channel:** {interaction.channel.mention}\n"
        f"**Count:** {deleted_count}"
        + (f"\n**Filtered to:** {member}" if member else ""),
        BLUE
    )
    await log_action(interaction.guild, e)

# -------- LOCK --------
@bot.tree.command(name="lock", description="Lock a channel so members can't send messages")
@mod_check("manage_channels")
@app_commands.describe(channel="Channel to lock (defaults to current)", reason="Reason for lock")
async def lock(interaction: discord.Interaction, channel: discord.TextChannel = None, reason: str = "No reason provided"):
    ch = channel or interaction.channel
    await ch.set_permissions(interaction.guild.default_role, send_messages=False)
    await interaction.response.send_message(embed=success_embed(f"{ch.mention} has been **locked**.\nReason: {reason}"))
    await ch.send(embed=make_embed("🔒 Channel Locked", f"This channel has been locked by {interaction.user.mention}.\nReason: {reason}", RED))
    e = make_embed("🔒 Channel Locked", f"**Channel:** {ch.mention}\n**Moderator:** {interaction.user}\n**Reason:** {reason}", RED)
    await log_action(interaction.guild, e)

# -------- UNLOCK --------
@bot.tree.command(name="unlock", description="Unlock a locked channel")
@mod_check("manage_channels")
@app_commands.describe(channel="Channel to unlock (defaults to current)")
async def unlock(interaction: discord.Interaction, channel: discord.TextChannel = None):
    ch = channel or interaction.channel
    await ch.set_permissions(interaction.guild.default_role, send_messages=None)
    await interaction.response.send_message(embed=success_embed(f"{ch.mention} has been **unlocked**."))
    await ch.send(embed=make_embed("🔓 Channel Unlocked", f"This channel has been unlocked by {interaction.user.mention}.", GREEN))

# -------- SLOWMODE --------
@bot.tree.command(name="slowmode", description="Set slowmode for a channel")
@mod_check("manage_channels")
@app_commands.describe(seconds="Slowmode delay in seconds (0 to disable)", channel="Channel to set slowmode on")
async def slowmode(interaction: discord.Interaction, seconds: int, channel: discord.TextChannel = None):
    ch = channel or interaction.channel
    await ch.edit(slowmode_delay=seconds)
    if seconds == 0:
        await interaction.response.send_message(embed=success_embed(f"Slowmode disabled in {ch.mention}."))
    else:
        await interaction.response.send_message(embed=success_embed(f"Slowmode set to **{seconds}s** in {ch.mention}."))

# -------- BLACKLIST --------
@bot.tree.command(name="blacklist", description="Blacklist a user — all their messages are auto-deleted")
@mod_check("administrator")
@app_commands.describe(member="Member to blacklist")
async def blacklist_cmd(interaction: discord.Interaction, member: discord.Member):
    blacklist.add(member.id)
    await interaction.response.send_message(embed=success_embed(f"**{member}** has been blacklisted."))
    e = make_embed("🚫 User Blacklisted", f"**User:** {member} (`{member.id}`)\n**By:** {interaction.user}", RED)
    await log_action(interaction.guild, e)

# -------- UNBLACKLIST --------
@bot.tree.command(name="unblacklist", description="Remove a user from the blacklist")
@mod_check("administrator")
@app_commands.describe(member="Member to unblacklist")
async def unblacklist_cmd(interaction: discord.Interaction, member: discord.Member):
    blacklist.discard(member.id)
    await interaction.response.send_message(embed=success_embed(f"**{member}** has been removed from the blacklist."))

# -------- ADD BADWORD --------
@bot.tree.command(name="addbadword", description="Add a custom bad word to the filter")
@mod_check("administrator")
@app_commands.describe(word="Word to add to the filter")
async def addbadword(interaction: discord.Interaction, word: str):
    custom_badwords.add(word.lower())
    await interaction.response.send_message(embed=success_embed(f"Added `{word}` to the bad word filter."), ephemeral=True)

# -------- REMOVE BADWORD --------
@bot.tree.command(name="removebadword", description="Remove a word from the custom bad word filter")
@mod_check("administrator")
@app_commands.describe(word="Word to remove from the filter")
async def removebadword(interaction: discord.Interaction, word: str):
    custom_badwords.discard(word.lower())
    await interaction.response.send_message(embed=success_embed(f"Removed `{word}` from the bad word filter."), ephemeral=True)

# -------- WHITELIST CHANNEL --------
@bot.tree.command(name="whitelistchannel", description="Whitelist a channel to bypass auto-moderation")
@mod_check("administrator")
@app_commands.describe(channel="Channel to whitelist")
async def whitelistchannel(interaction: discord.Interaction, channel: discord.TextChannel = None):
    ch = channel or interaction.channel
    whitelist_channels.add(ch.id)
    await interaction.response.send_message(embed=success_embed(f"{ch.mention} is now **whitelisted** from auto-mod."))

# -------- UNWHITELIST CHANNEL --------
@bot.tree.command(name="unwhitelistchannel", description="Remove a channel from the whitelist")
@mod_check("administrator")
@app_commands.describe(channel="Channel to remove from whitelist")
async def unwhitelistchannel(interaction: discord.Interaction, channel: discord.TextChannel = None):
    ch = channel or interaction.channel
    whitelist_channels.discard(ch.id)
    await interaction.response.send_message(embed=success_embed(f"{ch.mention} has been removed from the whitelist."))

# -------- USERINFO --------
@bot.tree.command(name="userinfo", description="Get information about a user")
@app_commands.describe(member="Member to get info about")
async def userinfo(interaction: discord.Interaction, member: discord.Member = None):
    member = member or interaction.user
    warns = await get_warns(member.id, interaction.guild.id)
    roles = [r.mention for r in member.roles if r != interaction.guild.default_role]

    e = discord.Embed(title=f"User Info — {member}", color=member.color if member.color.value else BLUE)
    e.set_thumbnail(url=member.display_avatar.url)
    e.add_field(name="ID", value=member.id, inline=True)
    e.add_field(name="Nickname", value=member.nick or "None", inline=True)
    e.add_field(name="Bot", value="Yes" if member.bot else "No", inline=True)
    e.add_field(name="Account Created", value=discord.utils.format_dt(member.created_at, "R"), inline=True)
    e.add_field(name="Joined Server", value=discord.utils.format_dt(member.joined_at, "R") if member.joined_at else "Unknown", inline=True)
    e.add_field(name="Warns", value=len(warns), inline=True)
    e.add_field(name=f"Roles ({len(roles)})", value=" ".join(roles[:10]) if roles else "None", inline=False)
    e.timestamp = discord.utils.utcnow()
    await interaction.response.send_message(embed=e)

# -------- SERVERINFO --------
@bot.tree.command(name="serverinfo", description="Get information about the server")
async def serverinfo(interaction: discord.Interaction):
    g = interaction.guild
    bots = sum(1 for m in g.members if m.bot)
    e = discord.Embed(title=g.name, color=BLUE)
    if g.icon:
        e.set_thumbnail(url=g.icon.url)
    e.add_field(name="Owner", value=g.owner.mention if g.owner else "Unknown", inline=True)
    e.add_field(name="ID", value=g.id, inline=True)
    e.add_field(name="Created", value=discord.utils.format_dt(g.created_at, "R"), inline=True)
    e.add_field(name="Members", value=g.member_count, inline=True)
    e.add_field(name="Bots", value=bots, inline=True)
    e.add_field(name="Humans", value=g.member_count - bots, inline=True)
    e.add_field(name="Channels", value=len(g.channels), inline=True)
    e.add_field(name="Roles", value=len(g.roles), inline=True)
    e.add_field(name="Boost Level", value=g.premium_tier, inline=True)
    e.add_field(name="Boosts", value=g.premium_subscription_count, inline=True)
    e.add_field(name="Verification Level", value=str(g.verification_level).title(), inline=True)
    e.timestamp = discord.utils.utcnow()
    await interaction.response.send_message(embed=e)

# -------- NOTE --------
@bot.tree.command(name="note", description="Add a private mod note to a user")
@mod_check("manage_messages")
@app_commands.describe(member="Member to add note to", note="The note content")
async def note_cmd(interaction: discord.Interaction, member: discord.Member, note: str):
    async with aiosqlite.connect(DB) as db:
        await db.execute(
            "INSERT INTO notes (user_id, guild_id, note, moderator_id) VALUES (?, ?, ?, ?)",
            (member.id, interaction.guild.id, note, interaction.user.id)
        )
        await db.commit()
    await interaction.response.send_message(embed=success_embed(f"Note added for **{member}**."), ephemeral=True)

# -------- NOTES --------
@bot.tree.command(name="notes", description="View all mod notes for a user")
@mod_check("manage_messages")
@app_commands.describe(member="Member to view notes for")
async def notes_cmd(interaction: discord.Interaction, member: discord.Member):
    async with aiosqlite.connect(DB) as db:
        cur = await db.execute(
            "SELECT note, moderator_id, timestamp FROM notes WHERE user_id=? AND guild_id=? ORDER BY timestamp DESC",
            (member.id, interaction.guild.id)
        )
        rows = await cur.fetchall()
    if not rows:
        await interaction.response.send_message(embed=info_embed("Notes", f"No notes for **{member}**."), ephemeral=True)
        return
    desc = "\n\n".join([f"**{ts[:10]}** — <@{mid}>\n{note}" for note, mid, ts in rows[:10]])
    await interaction.response.send_message(embed=make_embed(f"Notes for {member}", desc, PURPLE), ephemeral=True)

# -------- ANNOUNCE --------
@bot.tree.command(name="announce", description="Send an announcement embed to a channel")
@mod_check("manage_messages")
@app_commands.describe(title="Announcement title", message="Announcement message", channel="Target channel", ping="Ping @everyone?")
async def announce(interaction: discord.Interaction, title: str, message: str, channel: discord.TextChannel = None, ping: bool = False):
    ch = channel or interaction.channel
    e = make_embed(f"📢 {title}", message, BLUE)
    e.set_footer(text=f"Announced by {interaction.user}")
    content = "@everyone" if ping else ""
    await ch.send(content=content, embed=e)
    await interaction.response.send_message(embed=success_embed(f"Announcement sent to {ch.mention}."), ephemeral=True)

# -------- SECURITY SCAN --------
@bot.tree.command(name="securityscan", description="Run a security scan on the server")
@mod_check("administrator")
async def securityscan(interaction: discord.Interaction):
    g = interaction.guild
    bots = [m for m in g.members if m.bot]
    new_accounts = [m for m in g.members if not m.bot and (discord.utils.utcnow() - m.created_at).days < 7]
    admins = [m for m in g.members if m.guild_permissions.administrator and not m.bot]
    no_2fa = g.mfa_level == 0

    e = discord.Embed(title="🛡️ Security Scan Report", color=CYAN)
    e.add_field(name="Total Members", value=g.member_count, inline=True)
    e.add_field(name="Bots", value=len(bots), inline=True)
    e.add_field(name="New Accounts (<7 days)", value=len(new_accounts), inline=True)
    e.add_field(name="Admins", value=len(admins), inline=True)
    e.add_field(name="2FA Required", value="❌ No" if no_2fa else "✅ Yes", inline=True)
    e.add_field(name="Verification Level", value=str(g.verification_level).title(), inline=True)
    e.add_field(name="Explicit Media Filter", value=str(g.explicit_content_filter).replace("_", " ").title(), inline=True)
    e.add_field(name="Blacklisted Users", value=len(blacklist), inline=True)
    e.add_field(name="Whitelisted Channels", value=len(whitelist_channels), inline=True)

    issues = []
    if no_2fa:
        issues.append("⚠️ 2FA for moderators is not required")
    if len(bots) > 20:
        issues.append("⚠️ Large number of bots detected")
    if len(new_accounts) > 5:
        issues.append(f"⚠️ {len(new_accounts)} accounts are less than 7 days old")

    e.add_field(name="Issues Found", value="\n".join(issues) if issues else "✅ No major issues", inline=False)
    e.timestamp = discord.utils.utcnow()
    await interaction.response.send_message(embed=e)

# -------- SETLOGCHANNEL (FIXED) --------
# Bug fix: INSERT OR REPLACE was wiping other settings columns to their defaults.
# Now uses proper ON CONFLICT DO UPDATE to only touch the log_channel column.
@bot.tree.command(name="setlogchannel", description="Set the channel for mod logs")
@mod_check("administrator")
@app_commands.describe(channel="The channel to send logs to")
async def setlogchannel(interaction: discord.Interaction, channel: discord.TextChannel):
    async with aiosqlite.connect(DB) as db:
        await db.execute(
            """INSERT INTO settings (guild_id, log_channel)
               VALUES (?, ?)
               ON CONFLICT(guild_id) DO UPDATE SET log_channel=excluded.log_channel""",
            (interaction.guild.id, channel.name)
        )
        await db.commit()
    await interaction.response.send_message(embed=success_embed(f"Mod logs will now be sent to {channel.mention}."))

# -------- SETMAXWARNS (FIXED) --------
# Bug fix: same INSERT OR REPLACE issue — fixed with ON CONFLICT DO UPDATE.
@bot.tree.command(name="setmaxwarns", description="Set the max warns before auto-mute")
@mod_check("administrator")
@app_commands.describe(amount="Max warnings before auto-action (default: 3)")
async def setmaxwarns(interaction: discord.Interaction, amount: int):
    if amount < 1 or amount > 20:
        await interaction.response.send_message(embed=error_embed("Max warns must be between 1 and 20."), ephemeral=True)
        return
    async with aiosqlite.connect(DB) as db:
        await db.execute(
            """INSERT INTO settings (guild_id, max_warns)
               VALUES (?, ?)
               ON CONFLICT(guild_id) DO UPDATE SET max_warns=excluded.max_warns""",
            (interaction.guild.id, amount)
        )
        await db.commit()
    await interaction.response.send_message(embed=success_embed(f"Max warns set to **{amount}**."))

# =================================================================
# =================== PERMISSION GRANT COMMANDS ==================
# =================================================================

# -------- PERMSGIVE --------
# Only admins and the server owner can grant permissions.
# Use command="all" to grant every command at once.
# Once granted, the target user can use that slash command even without
# the native Discord permission.
@bot.tree.command(name="permsgive", description="Grant a user permission to use a specific command (or 'all' for every command)")
@mod_check("administrator")
@app_commands.describe(
    member="Member to grant permission to",
    command="Slash command name (e.g. kick, ban, purge) — or type 'all' to grant every command"
)
async def permsgive(interaction: discord.Interaction, member: discord.Member, command: str):
    command = command.lower().strip()
    all_cmds = sorted([c.name for c in bot.tree.get_commands()])

    if command == "all":
        async with aiosqlite.connect(DB) as db:
            for cmd_name in all_cmds:
                await db.execute(
                    "INSERT OR IGNORE INTO cmd_permissions (guild_id, user_id, command_name) VALUES (?, ?, ?)",
                    (interaction.guild.id, member.id, cmd_name)
                )
            await db.commit()
        cmd_list = "\n".join([f"`/{c}`" for c in all_cmds])
        await interaction.response.send_message(
            embed=make_embed(
                "🔑 All Permissions Granted",
                f"**{member.mention}** has been granted access to **all {len(all_cmds)} commands**:\n\n{cmd_list}",
                PURPLE
            )
        )
        e = make_embed(
            "🔑 All Permissions Granted",
            f"**User:** {member} (`{member.id}`)\n"
            f"**Commands:** ALL ({len(all_cmds)} commands)\n"
            f"**Granted by:** {interaction.user}",
            PURPLE
        )
        await log_action(interaction.guild, e)
        return

    if command not in all_cmds:
        await interaction.response.send_message(
            embed=error_embed(
                f"No command named `{command}` found.\n\n"
                f"**Available commands:**\n`{'`, `'.join(all_cmds)}`\n\n"
                f"Tip: Use `all` to grant every command at once."
            ),
            ephemeral=True
        )
        return

    async with aiosqlite.connect(DB) as db:
        await db.execute(
            "INSERT OR IGNORE INTO cmd_permissions (guild_id, user_id, command_name) VALUES (?, ?, ?)",
            (interaction.guild.id, member.id, command)
        )
        await db.commit()
    await interaction.response.send_message(
        embed=success_embed(f"**{member.mention}** has been granted access to `/{command}`.")
    )
    e = make_embed(
        "🔑 Permission Granted",
        f"**User:** {member} (`{member.id}`)\n"
        f"**Command:** `/{command}`\n"
        f"**Granted by:** {interaction.user}",
        PURPLE
    )
    await log_action(interaction.guild, e)

# -------- PERMSREVOKE --------
# Use command="all" to revoke every granted permission at once.
@bot.tree.command(name="permsrevoke", description="Revoke a user's granted command permission (or 'all' to revoke everything)")
@mod_check("administrator")
@app_commands.describe(
    member="Member to revoke permission from",
    command="Slash command name to revoke — or type 'all' to revoke every granted command"
)
async def permsrevoke(interaction: discord.Interaction, member: discord.Member, command: str):
    command = command.lower().strip()

    if command == "all":
        async with aiosqlite.connect(DB) as db:
            cur = await db.execute(
                "SELECT command_name FROM cmd_permissions WHERE guild_id=? AND user_id=?",
                (interaction.guild.id, member.id)
            )
            rows = await cur.fetchall()
            if not rows:
                await interaction.response.send_message(
                    embed=error_embed(f"**{member}** has no granted permissions to revoke."),
                    ephemeral=True
                )
                return
            await db.execute(
                "DELETE FROM cmd_permissions WHERE guild_id=? AND user_id=?",
                (interaction.guild.id, member.id)
            )
            await db.commit()
        count = len(rows)
        await interaction.response.send_message(
            embed=success_embed(f"Revoked **all {count} command permissions** from **{member.mention}**.")
        )
        e = make_embed(
            "🔒 All Permissions Revoked",
            f"**User:** {member} (`{member.id}`)\n"
            f"**Commands revoked:** {count}\n"
            f"**Revoked by:** {interaction.user}",
            RED
        )
        await log_action(interaction.guild, e)
        return

    async with aiosqlite.connect(DB) as db:
        cur = await db.execute(
            "SELECT 1 FROM cmd_permissions WHERE guild_id=? AND user_id=? AND command_name=?",
            (interaction.guild.id, member.id, command)
        )
        row = await cur.fetchone()
        if not row:
            await interaction.response.send_message(
                embed=error_embed(f"**{member}** does not have a grant for `/{command}`."),
                ephemeral=True
            )
            return
        await db.execute(
            "DELETE FROM cmd_permissions WHERE guild_id=? AND user_id=? AND command_name=?",
            (interaction.guild.id, member.id, command)
        )
        await db.commit()
    await interaction.response.send_message(
        embed=success_embed(f"Revoked `/{command}` permission from **{member.mention}**.")
    )
    e = make_embed(
        "🔒 Permission Revoked",
        f"**User:** {member} (`{member.id}`)\n"
        f"**Command:** `/{command}`\n"
        f"**Revoked by:** {interaction.user}",
        RED
    )
    await log_action(interaction.guild, e)

# -------- PERMSLIST --------
@bot.tree.command(name="permslist", description="List all custom command permissions granted in this server")
@mod_check("administrator")
async def permslist(interaction: discord.Interaction):
    async with aiosqlite.connect(DB) as db:
        cur = await db.execute(
            "SELECT user_id, command_name FROM cmd_permissions WHERE guild_id=? ORDER BY command_name",
            (interaction.guild.id,)
        )
        rows = await cur.fetchall()
    if not rows:
        await interaction.response.send_message(
            embed=info_embed("Custom Permissions", "No custom permissions have been granted in this server."),
            ephemeral=True
        )
        return
    desc = "\n".join([f"<@{uid}> → `/{cmd}`" for uid, cmd in rows])
    await interaction.response.send_message(
        embed=make_embed("🔑 Custom Permissions", desc, PURPLE),
        ephemeral=True
    )

# ================= RUN =================
bot.run(TOKEN)